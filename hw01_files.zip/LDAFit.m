function [w,b] = LDAFit(X,Y)
%LDAFit 
%   Function that takes as input 
%       X: a d x n matrix where each column corresponds to a feature vector
%          in R^d
%       Y: a 1 x n vector of binary labels (0,1) for each training vector
%   and generates an output of
%       w: a d x 1 normal vector
%       b: an offset for the separating hyperplane
%   using LDA

[d,n] = size(X);

idx0 = find(Y==0); % X(:,idx0) corresponds to all training vectors labeled 0
idx1 = find(Y==1); % X(:,idx1) corresponds to all training vectors labeled 1

n0 = length(idx0); % number of training vectors labeled 0
n1 = length(idx1); % number of training vectors labeled 1

pi_hat_0 = ???
pi_hat_1 = ???

mu_hat_0 = ???
mu_hat_1 = ???

Sigma_hat = ???

w = ???
b = ???

